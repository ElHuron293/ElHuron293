#!/usr/bin/python3


# Module for clientsocket


import os, sys, socket


def _client_socket(HOST, PORT, FILENAME):
	try:
		c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		c.connect((HOST, PORT))

		# get size of file
		FILESIZE = os.path.getsize(FILENAME)
		if FILESIZE > 10**6:
			fsize = f"{round(FILESIZE / (10**6), 2)} MB"
		else:
			fsize = f"{round(FILESIZE / (10**3), 2)} KB"

		# send filename as binary to server, fill up spaces with '+' to a 1024 byte string
		FN = f"{FILENAME.split('/')[-1]}<end>{fsize}<end>{FILESIZE}<end>"
		if len(FN.encode("utf-8")) > 999:
			sys.exit("Filename passed max. size of 999 bytes!!!")
		else:
			for n in range(1024 - len(FN.encode("utf-8"))):
				FN += "+"
			c.send((FN).encode("utf-8"))

		# get processing time in percent
		i = 1
		def proc(_i):
			print(f"Progress: {round((_i * 8192) / FILESIZE * 100)}%", end="\r")

		# send data-chunks from file to server
		with open(FILENAME, "rb") as f:
			while True:
				cdata = f.read(8192)
				if not cdata:
					break
				c.send(cdata)

				i += 1 ; proc(i)

		print(f"Data sent to: {HOST}")

		c.shutdown(socket.SHUT_RDWR)
		c.close()

	except ConnectionResetError:
		sys.exit(f"ConnectionError: File '{FILENAME}' not sent!!! Please try again.")
	except (ConnectionRefusedError, OSError):
		sys.exit("Server connection failed!!!")



