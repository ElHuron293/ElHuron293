#!/usr/bin/python3


# Module for serversocket


import os, sys, socket


def _server_socket(HOST, PORT, DIR):
	print(f"Server is running on ip-a {HOST} and port {PORT}")
	print("-------------------------------------------------------")
	print("Strg^C will end the server (Keybord Interrupt)\n")
	# run server in an endless-loop -> end with Strg^C (Keyboard Interrupt)
	try:
		while True:
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			try:
				s.bind((HOST, PORT))
			except (socket.gaierror, OSError):
				sys.exit("Couldn't validate given IP-address!!!")
			s.listen(1)
			conn, addr = s.accept()
			print(f"Incomming file from {addr}.")
			
			# receive info (bytes) of transmitted file and write it to list
			fargs = conn.recv(1024)
			lst_fargs = (fargs.decode("utf-8")).split("<end>")

			fname = lst_fargs[0]		# filename
			fsize = int(lst_fargs[2])	# filesize
			print(f"Filesize: {lst_fargs[1]}")

			# get porgress of file transmission
			i = 0
			def proc(_i):
				print(f"Progress: {round(_i / fsize * 100)}%", end="\r")				

			# write transmitted bytes of file back to new file
			try:
				with open(f"{DIR}/{fname}", "wb") as f:
					while True:
						cdata = conn.recv(8192)
						f.write(cdata)
						if not cdata:
							break

						i += len(cdata) ; proc(i)	

			except IsADirectoryError:
				pass

			# info to written file
			if fname == "":
				print("FileTransmissionError -> No file written!!!\n")
			else:
				print(f"File '{fname}' is ready in '{DIR}'.\n")

	except KeyboardInterrupt:
		print("\nKeyboard interrupt received, exiting server.")
		sys.exit(0)



